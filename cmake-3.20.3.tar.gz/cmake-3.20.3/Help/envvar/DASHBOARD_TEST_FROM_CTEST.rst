DASHBOARD_TEST_FROM_CTEST
-------------------------

.. include:: ENV_VAR.txt

Environment variable that will exist when a test executed by :manual:`ctest(1)`
is run in non-interactive mode.  The value will be equal to
:variable:`CMAKE_VERSION`.

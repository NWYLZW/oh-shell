.. cmake-module:: ../../Modules/FindGDAL.cmake
